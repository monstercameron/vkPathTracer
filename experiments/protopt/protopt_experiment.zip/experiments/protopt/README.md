# protopt — tiny D3D12 sphere prototype

`protopt` is a deliberately tiny Windows/Direct3D 12 experiment for feeling out the larger C++ pathtracer project without building the full engine.

It opens a Win32 window, renders a ray-sphere scene in a fullscreen HLSL pixel shader, rotates the camera over time, and updates the window title with quick benchmark-style metrics:

- FPS
- ms/frame
- approximate rays/sec, one primary ray per pixel
- resolution
- frame index
- selected GPU adapter

This is **not** the scalable engine architecture. It belongs in `experiments/protopt` and should stay disposable.

## Requirements

- Windows 10/11
- Windows SDK with Direct3D 12 headers/libs
- CMake 3.25+
- clang-cl, MSVC, or Visual Studio with C++ workload
- D3D12-capable GPU; the app falls back to WARP if needed

## Build with Visual Studio generator + clang-cl

```powershell
cd experiments\protopt
cmake -S . -B build -G "Visual Studio 17 2022" -T ClangCL
cmake --build build --config Release
.\build\Release\protopt.exe
```

## Build with Ninja + clang-cl

Run from a Developer PowerShell where Windows SDK environment variables are available:

```powershell
cd experiments\protopt
cmake -S . -B build-ninja -G Ninja -DCMAKE_CXX_COMPILER=clang-cl
cmake --build build-ninja --config Release
.\build-ninja\protopt.exe
```

## Debug notes

The app writes a simple log file next to the executable/current working directory:

```text
protopt_log.txt
```

If initialization fails, check that file first. It logs the selected adapter, D3D12 init stages, shader compile errors, resize events, and shutdown.

## Scope lock

Keep this experiment small:

- no ECS
- no asset system
- no UI panels
- no benchmark artifact system
- no shader cache
- no real path tracing accumulation
- no hardware RT path

The only goal is to quickly see a native D3D12 window rendering a simple raytraced sphere with rotating camera and live title metrics.
