$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
cmake -S . -B build -G "Visual Studio 17 2022" -T ClangCL
cmake --build build --config Release
& .\build\Release\protopt.exe
